"""
code.friend — Main FastAPI Application
Entry point for the backend server.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os

from routes.transpile import router as transpile_router
from routes.explain   import router as explain_router
from routes.review    import router as review_router
from routes.simulate  import router as simulate_router
from routes.chat      import router as chat_router

# ── App Setup ──
app = FastAPI(
    title="code.friend API",
    version="5.0.0",
    description="AI-powered code transpiler backend using Groq LLaMA",
)

# ── CORS Middleware ──
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Register Routes ──
app.include_router(transpile_router)
app.include_router(explain_router)
app.include_router(review_router)
app.include_router(simulate_router)
app.include_router(chat_router)

# ── Root & Health ──
@app.get("/")
async def root():
    return {
        "status":  "ok",
        "service": "code.friend",
        "version": "5.0.0",
        "model":   "llama-3.3-70b-versatile",
        "docs":    "/docs",
    }

@app.get("/health")
async def health():
    api_key = os.getenv("GROQ_API_KEY", "")
    return {
        "status": "ok",
        "api_key_configured": bool(api_key),
    }
