"""
routes/review.py
POST /review — AI code review with bug detection and suggestions.
"""

import logging
from fastapi import APIRouter, HTTPException
from models.schemas import ReviewRequest, APIResponse
from services.groq_client import call_groq

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/review", response_model=APIResponse)
async def review(req: ReviewRequest):
    """
    Perform an AI code review on the given code.

    - **source_code**: The code to review
    - **language**: The programming language of the code
    """
    if not req.source_code.strip():
        raise HTTPException(status_code=400, detail="source_code cannot be empty")

    system = f"""You are a senior software engineer performing a thorough code review.

Review the following {req.language} code and provide actionable feedback on:
- Bugs or logical errors
- Security vulnerabilities
- Performance issues
- Code style and readability
- Best practices violations
- Suggested improvements

Be specific — reference line numbers or code snippets where possible.
End with an overall quality rating out of 10 and a one-line summary.
Use plain text only — no markdown."""

    user = f"Review this {req.language} code:\n\n{req.source_code}"

    logger.info(f"Review: {req.language} | {len(req.source_code)} chars")

    result = await call_groq(system, user, max_tokens=2048)
    return APIResponse(result=result.strip())
