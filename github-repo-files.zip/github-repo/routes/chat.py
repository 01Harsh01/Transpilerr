"""
routes/chat.py
POST /chat — AI coding assistant chat endpoint.
"""

import logging
from fastapi import APIRouter, HTTPException
from models.schemas import ChatRequest, APIResponse
from services.groq_client import call_groq

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/chat", response_model=APIResponse)
async def chat(req: ChatRequest):
    """
    Chat with the AI coding assistant.

    - **message**: The user's question or message
    - **code**: Optional — current code in the editor (for context)
    - **language**: Optional — current language selected
    """
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="message cannot be empty")

    # Include editor code as context if provided
    code_context = ""
    if req.code and req.code.strip():
        code_context = f"\n\nThe user currently has this {req.language} code in their editor:\n{req.code[:2000]}"

    system = f"""You are code.friend — a helpful, friendly AI coding assistant.
Help developers with coding questions, debugging, explanations, and best practices.
Be concise, practical, and friendly.
Use plain text only — no markdown.{code_context}"""

    user = req.message

    logger.info(f"Chat: {req.message[:60]}")

    result = await call_groq(system, user, max_tokens=1024)
    return APIResponse(result=result.strip())
