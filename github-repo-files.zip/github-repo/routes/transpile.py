"""
routes/transpile.py
POST /transpile — Convert code from one language to another.
"""

import logging
from fastapi import APIRouter, HTTPException
from models.schemas import TranspileRequest, APIResponse
from services.groq_client import call_groq, strip_markdown_fences

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/transpile", response_model=APIResponse)
async def transpile(req: TranspileRequest):
    """
    Transpile source code from one programming language to another.

    - **source_code**: The code you want to convert
    - **from_lang**: The language the code is written in
    - **to_lang**: The language to convert to
    - **extra_instructions**: Optional extra instructions for the AI
    """
    if not req.source_code.strip():
        raise HTTPException(status_code=400, detail="source_code cannot be empty")

    if req.from_lang == req.to_lang:
        raise HTTPException(status_code=400, detail="from_lang and to_lang must be different")

    system = f"""You are an expert code transpiler and software engineer.
Convert code from {req.from_lang} to {req.to_lang}.

STRICT RULES:
- Return ONLY the raw transpiled code — nothing else
- NO markdown code fences (no ```)
- NO explanations, NO preamble, NO extra text
- Preserve all comments from the original code
- The code must be clean and idiomatic {req.to_lang}
- Use {req.to_lang} best practices and naming conventions
- If source uses libraries, use the closest {req.to_lang} equivalents
{f"- Extra instructions: {req.extra_instructions}" if req.extra_instructions else ""}"""

    user = f"Convert this {req.from_lang} code to {req.to_lang}:\n\n{req.source_code}"

    logger.info(f"Transpile: {req.from_lang} → {req.to_lang} | {len(req.source_code)} chars")

    result = await call_groq(system, user, max_tokens=4096)
    result = strip_markdown_fences(result)

    return APIResponse(result=result)
