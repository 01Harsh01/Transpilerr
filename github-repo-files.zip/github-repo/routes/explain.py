"""
routes/explain.py
POST /explain — Explain what a piece of code does.
"""

import logging
from fastapi import APIRouter, HTTPException
from models.schemas import ExplainRequest, APIResponse
from services.groq_client import call_groq

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/explain", response_model=APIResponse)
async def explain(req: ExplainRequest):
    """
    Explain what the given code does in plain English.

    - **source_code**: The code to explain
    - **language**: The programming language of the code
    """
    if not req.source_code.strip():
        raise HTTPException(status_code=400, detail="source_code cannot be empty")

    system = f"""You are a friendly expert coding assistant.
Explain the following {req.language} code clearly and concisely.

Cover these points:
1. What the code does (a simple overview)
2. How it works step by step
3. Key concepts and patterns used
4. Any potential issues or improvements

Keep it clear and beginner-friendly. Use plain text only — no markdown."""

    user = f"Explain this {req.language} code:\n\n{req.source_code}"

    logger.info(f"Explain: {req.language} | {len(req.source_code)} chars")

    result = await call_groq(system, user, max_tokens=2048)
    return APIResponse(result=result.strip())
