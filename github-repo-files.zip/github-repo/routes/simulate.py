"""
routes/simulate.py
POST /simulate — Simulate code execution and return terminal output.
"""

import logging
from fastapi import APIRouter, HTTPException
from models.schemas import SimulateRequest, APIResponse
from services.groq_client import call_groq

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/simulate", response_model=APIResponse)
async def simulate(req: SimulateRequest):
    """
    Simulate running the code and return what it would print to the terminal.

    - **code**: The code to simulate
    - **language**: The programming language of the code
    """
    if not req.code.strip():
        raise HTTPException(status_code=400, detail="code cannot be empty")

    system = f"""You are a precise code execution simulator.

Mentally execute the following {req.language} code and return ONLY what would
be printed to stdout / the console.

Rules:
- No explanation
- No markdown
- Just the raw terminal output exactly as it would appear
- If nothing is printed, return exactly: (no output)
- Maximum 20 lines of output"""

    user = f"Simulate this {req.language} code:\n\n{req.code}"

    logger.info(f"Simulate: {req.language}")

    result = await call_groq(system, user, max_tokens=512)
    return APIResponse(result=result.strip())
