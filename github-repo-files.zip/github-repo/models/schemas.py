"""
models/schemas.py
All request/response data models used across routes.
"""

from pydantic import BaseModel
from typing import Optional


class TranspileRequest(BaseModel):
    """Request body for /transpile endpoint."""
    source_code:        str
    from_lang:          str
    to_lang:            str
    extra_instructions: Optional[str] = ""


class ExplainRequest(BaseModel):
    """Request body for /explain endpoint."""
    source_code: str
    language:    str


class ReviewRequest(BaseModel):
    """Request body for /review endpoint."""
    source_code: str
    language:    str


class SimulateRequest(BaseModel):
    """Request body for /simulate endpoint."""
    code:     str
    language: str


class ChatRequest(BaseModel):
    """Request body for /chat endpoint."""
    message:  str
    code:     Optional[str] = ""
    language: Optional[str] = ""


class APIResponse(BaseModel):
    """Standard response returned by all endpoints."""
    result: str
