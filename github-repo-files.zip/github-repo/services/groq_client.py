"""
services/groq_client.py
Handles all communication with the Groq API.
"""

import httpx
import os
from fastapi import HTTPException

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_URL     = "https://api.groq.com/openai/v1/chat/completions"
MODEL        = "llama-3.3-70b-versatile"


async def call_groq(system: str, user: str, max_tokens: int = 4096) -> str:
    """
    Send a request to Groq and return the text response.

    Args:
        system:     The system prompt (instructions for the AI)
        user:       The user message (the actual code/question)
        max_tokens: Maximum tokens in the response

    Returns:
        The AI's text response as a string.
    """
    if not GROQ_API_KEY:
        raise HTTPException(
            status_code=500,
            detail="GROQ_API_KEY is not set. Add it in Render → Environment."
        )

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type":  "application/json",
    }

    payload = {
        "model":      MODEL,
        "max_tokens": max_tokens,
        "temperature": 0.2,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
    }

    async with httpx.AsyncClient(timeout=60.0) as client:
        resp = await client.post(GROQ_URL, headers=headers, json=payload)

    if resp.status_code != 200:
        error = resp.json()
        message = error.get("error", {}).get("message", "Groq API error")
        raise HTTPException(status_code=resp.status_code, detail=message)

    data = resp.json()

    try:
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        raise HTTPException(status_code=500, detail="Unexpected response from Groq API")


def strip_markdown_fences(code: str) -> str:
    """
    Remove markdown code fences if the AI accidentally adds them.
    e.g. ```python ... ``` → just the code
    """
    code = code.strip()
    if code.startswith("```"):
        lines = code.split("\n")
        # Remove first line (```python) and last line (```)
        end = -1 if lines[-1].strip() == "```" else len(lines)
        code = "\n".join(lines[1:end])
    return code.strip()
