# code.friend — AI Code Transpiler
### Powered by Google Gemini (FREE — no credit card needed)

Convert code between 21 programming languages. Users just open the site and use it.

---

## 📁 Files

```
backend/
  main.py            ← FastAPI server (connects to Gemini AI)
  requirements.txt   ← Python packages
  Procfile           ← For Render/Railway
  railway.toml       ← Railway config
  render.yaml        ← Render config
  .env.example       ← Environment variable template

frontend/
  index.html         ← Complete web app (single file, deploy anywhere)
```

---

## 🔑 STEP 1 — Get FREE Gemini API Key (3 minutes, no card)

1. Go to → **https://aistudio.google.com/app/apikey**
2. Sign in with your Google account
3. Click **"Create API key"**
4. Copy the key (looks like: `AIzaSyXXXXXXXXXXXXXXXXXXXXXX`)
5. That's it — completely free!

---

## 🖥 STEP 2 — Deploy Backend on Render (free)

### 2a. Push backend to GitHub
1. Create a new repo on **github.com**
2. Upload everything inside the `backend/` folder to that repo
3. Make sure `.env` is in `.gitignore` (it is already)

### 2b. Deploy on Render
1. Go to **https://render.com** → sign up free
2. Click **"New +"** → **"Web Service"**
3. Connect your GitHub → select your repo
4. Render auto-detects Python. Set:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Scroll to **"Environment Variables"** → click **"Add Variable"**:
   - Key:   `GEMINI_API_KEY`
   - Value: `AIzaSyYOUR_KEY_HERE`
6. Click **"Create Web Service"**
7. Wait ~2 min → you get a URL like:
   `https://codefriend-api.onrender.com`

✅ Test it: open `https://your-url.onrender.com/health` in browser
   You should see: `{"status":"ok","api_key_configured":true}`

---

## 🌐 STEP 3 — Deploy Frontend (free, 30 seconds)

### Option A: Netlify Drop (easiest)
1. Go to **https://netlify.com/drop**
2. Drag `frontend/index.html` onto the page
3. Done! You get a URL like `https://amazing-name-123.netlify.app`

### Option B: GitHub Pages
1. Create a repo, put `index.html` in it
2. Settings → Pages → Deploy from main branch
3. Live at `https://yourusername.github.io/reponame`

---

## 🔗 STEP 4 — Connect Frontend to Backend

1. Open your live frontend URL
2. Click **"⚡ connect"** in the top-right
3. Paste your Render backend URL:
   `https://codefriend-api.onrender.com`
4. Click **"save & connect"**
5. Badge turns green: **"connected"** ✓
6. Start transpiling! 🎉

> This URL is saved in the browser. Your users won't need to do this
> if you hardcode the URL — see "Production tip" below.

---

## 🚀 Production Tip — Hardcode the backend URL

To skip the connect step for all users, open `frontend/index.html`
and find this line near the bottom:

```javascript
S.url = localStorage.getItem('cf3_url') || '';
```

Change it to:

```javascript
S.url = 'https://your-actual-backend.onrender.com';
```

Then redeploy the frontend. Users will connect automatically!

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| ⟳ Transpile | Convert code between 21 languages |
| 💡 Explain | AI explains what your code does |
| 🔍 Review | AI reviews code for bugs & best practices |
| 📟 Terminal | Simulates execution output |
| 💬 Chat | Floating AI coding assistant |
| 📋 History | Last 60 transpilations saved locally |
| ⌨️ Shortcuts | Ctrl+Enter = transpile, Ctrl+D = clear |

## 🌍 Supported Languages

Python, JavaScript, TypeScript, Java, C++, C, Go, Rust, Ruby,
PHP, Swift, Kotlin, C#, Bash, R, Lua, Dart, Scala, Haskell, Elixir, SQL

---

## 🔌 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Check server status |
| `/transpile` | POST | Convert code between languages |
| `/explain` | POST | Explain code in plain English |
| `/review` | POST | Code review with feedback |
| `/simulate` | POST | Simulate execution output |
| `/chat` | POST | Chat with AI assistant |

---

## 💰 Cost

**Gemini 2.0 Flash is FREE** under Google's free tier:
- 15 requests per minute
- 1 million tokens per day
- No credit card required

More than enough for a personal/small project!

---

## 🔒 Security

- Your Gemini API key lives only on the Render server as an env variable
- Users of your site NEVER see the key
- Set `ALLOWED_ORIGINS` to your frontend domain in production:
  `ALLOWED_ORIGINS=https://yourapp.netlify.app`
